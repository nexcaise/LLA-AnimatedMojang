# Animated Mojang for Minecraft Bedrock (Android ARM64)

[![Platform](https://img.shields.io/badge/Platform-Android%20ARM64-green.svg)](https://github.com/rehan-remade/universal-modder)
[![Engine](https://img.shields.io/badge/Engine-Bedrock%20v1.26.52.3-blue.svg)](https://minecraft.net)
[![Mod Loader](https://img.shields.io/badge/Loader-LeviLaunchroid%20%2F%20LeviLamina-orange.svg)](https://github.com/LiteLDev/LeviLamina)
[![Architecture](https://img.shields.io/badge/Implementation-100%25%20Pure%20C%2B%2B%20(No%20RP)-purple.svg)](src/)

A high-performance, native C++ client mod for **Minecraft Bedrock Edition (Android ARM64)** running on **LeviLaunchroid** (LeviLamina Android). It reproduces the iconic, cinematic Java Edition mod [chara2015/animated_mojang](https://github.com/chara2015/animated_mojang) and its Bedrock port [MRUIAW/Animated-Mojang](https://github.com/MRUIAW/Animated-Mojang) with **100% pure C++ execution** and zero resource pack dependencies.

---

## Visual Showcase

![Animated Mojang Main Menu Showcase](icon.png)

*The Minecraft Title at full vanilla grand width (~1353px on 2460x1080 display), with animated frame playback, angled splash text, and the real-time 3D cave background rendered smoothly behind UI controls.*

---

## Key Features

1. **100% Pure C++ Implementation (Zero Resource Pack Dependency)**:
   - All textures (69-frame Minecraft title animation, cave atlas, and loading backdrop) are loaded directly from disk into GPU memory as native raw textures.
   - Eliminates resource pack conflicts, missing manifest errors, and UI JSON overrides.

2. **Full-Width Grand Animated Minecraft Title**:
   - 69-frame title animation sequence rendered frame-by-frame using `MinecraftUIRenderContext::drawImage` (RVA `0x0b25099c`) and `flushImages("ui_textured_and_color")` (RVA `0x0b251d70`).
   - Automatically crawls the JSON UI `UIControl` visual tree (`mVisualTree->mRootControl`), temporarily masks the static vanilla title (`mAlpha = 0`), and renders the animated frames at the exact vanilla coordinates above the Play button.
   - Preserves vanilla angled yellow splash text and Mojang copyright notice without visual clipping.

3. **Real-Time 3D Cave Background**:
   - Renders the authentic `normal_cave.mesh` geometry directly via an embedded OpenGL ES 3.0 renderer hooked into the game's render loop (`glClear`).
   - Natural cubic spline camera flight across 3 opening keyframes (`OPENER_START`, `OPENER_TRANSFER`, `TITLE`) with smooth cubic-bezier easing `(0.2, 0.32, 0.2, 1.0)`.
   - Subtle procedural ambient camera swaying during menu idle state.

4. **Instantaneous, Lag-Free Sub-Menu Camera Transitions**:
   - Distinct, cinematic camera perspectives tailored for every menu screen:
     - **Main Start Screen**: `(31.0, 13.0, 6.0, yaw=21.0, pitch=-13.0, roll=0.0)`
     - **Worlds / Play Screen**: `(28.0, 12.0, 14.0, yaw=15.0, pitch=-8.0, roll=0.0)`
     - **Settings Screen**: `(24.0, 14.0, 25.0, yaw=30.0, pitch=-5.0, roll=0.0)`
     - **Realms Screen**: `(33.0, 11.0, 10.0, yaw=10.0, pitch=-15.0, roll=0.0)`
     - **Marketplace Screen**: `(20.0, 15.0, 35.0, yaw=45.0, pitch=-2.0, roll=0.0)`
     - **Dressing Room / Profile**: `(35.0, 12.0, 5.0, yaw=5.0, pitch=-20.0, roll=0.0)`
   - Pure native route detection prevents UI freeze and ensures instantaneous transitions when opening and exiting menus.

5. **Smooth UI Fade-In**:
   - Buttons and interactive widgets smoothly fade in (`alpha: 0.0 -> 1.0`) between 2,700 ms and 3,200 ms after the opening flight begins, perfectly synchronized with audio and title reveals.

---

## Technical Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                       Minecraft Bedrock ARM64 Client                        │
└──────────────────────────────────────┬──────────────────────────────────────┘
                                       │
        ┌──────────────────────────────┴──────────────────────────────┐
        ▼                                                             ▼
┌──────────────────────────────┐              ┌──────────────────────────────┐
│       GLES Render Pass       │              │     JSON UI Render Pass      │
│     (Cave 3D Background)     │              │       (UI Controls)          │
└──────────────┬───────────────┘              └──────────────┬───────────────┘
               │                                             │
               ▼                                             ▼
  [Hook: glClear detour]                         [Hook: ScreenView::render]
  • Bind Cave Mesh VBO/VAO                       • Inspect VisualTree
  • Evaluate Camera Spline                       • Find "minecraft_title"
  • Draw 3D Cave Geometry                        • Set titleControl->mAlpha = 0
  • Pass Depth to UI Layer                       • drawImage(titleFrame, vanillaRect)
                                                 • Call origin(base) -> Draw Buttons
```

### Verified Engine Symbols & Offsets (Bedrock v1.26.52.3 ARM64)

All offsets are empirically verified using the [Bedrock Reverse Engineering Studio](../../tools/re_studio/) and stored in `offsets_1.26.52.3_arm64.json`:

| Symbol / Function Name | Type / VTable Slot | ARM64 RVA | Verification Status |
|---|---|---|---|
| `MinecraftUIRenderContext::drawImage` | VTable Slot 07 (`0x12d5bd68`) | `0x0b25099c` | `VERIFIED_GOLDEN_PASS_10` |
| `MinecraftUIRenderContext::flushImages` | VTable Slot 09 (`0x12d5bd78`) | `0x0b251d70` | `VERIFIED_GOLDEN_PASS_10` |
| `MinecraftUIRenderContext::fillRectangle` | VTable Slot 10 (`0x12d5bd80`) | `0x0b25232c` | `VERIFIED_GOLDEN_PASS_10` |
| `MinecraftUIRenderContext::drawRectangle` | VTable Slot 11 (`0x12d5bd88`) | `0x0b2536fc` | `VERIFIED_GOLDEN_PASS_10` |
| `MinecraftUIRenderContext::getLineLength` | VTable Slot 02 (`0x12d5bd40`) | `0x0b2507a4` | `VERIFIED_GOLDEN_PASS_10` |
| `MinecraftUIRenderContext::drawText` | VTable Slot 05 (`0x12d5bd58`) | `0x0b2507dc` | `VERIFIED_GOLDEN_PASS_10` |
| `MinecraftUIRenderContext::flushText` | VTable Slot 06 (`0x12d5bd60`) | `0x0b2508dc` | `VERIFIED_GOLDEN_PASS_10` |
| `MinecraftUIRenderContext::drawNineslice` | VTable Slot 08 (`0x12d5bd70`) | `0x0b25198c` | `VERIFIED_GOLDEN_PASS_10` |
| `MinecraftUIRenderContext::getScreenContext` | VTable Slot 13 (`0x12d5bd98`) | `0x0b2541e8` | `VERIFIED_GOLDEN_PASS_10` |
| `ScreenView::render` | Direct Member Method | `0x096961e4` | `VERIFIED_PASS_1` |
| `ui::ScreenTechStackSelector::getTechStackForScreen` | Direct Member Method | `0x0974e844` | `VERIFIED_GOLDEN_PASS_10` |
| `CubemapBackgroundScreen::render` | VTable Slot 02 (`0x12c011e8`) | `0x09b7c9e0` | `VERIFIED_GOLDEN_PASS_10` |
| `StartMenuScreenController::onOpen` | VTable Slot 14 (`0x12cae3b0`) | `0x0a2df314` | `VERIFIED_GOLDEN_PASS_10` |
| `StartMenuScreenController::tick` | VTable Slot 03 (`0x12cae358`) | `0x0a2e1ff4` | `VERIFIED_GOLDEN_PASS_10` |
| `PanoramaRenderer::render` | VTable Slot 03 (`0x12bb1770`) | `0x0967fa08` | `VERIFIED_GOLDEN_PASS_10` |
| `PaperDollRenderer::render` | VTable Slot 03 (`0x12bb1988`) | `0x09681f04` | `VERIFIED_GOLDEN_PASS_10` |
| `ProgressBarRenderer::render` | VTable Slot 03 (`0x12bb1ad8`) | `0x09685ea4` | `VERIFIED_GOLDEN_PASS_10` |

---

## Directory Structure

```
examples/animated-mojang-android/
├── CMakeLists.txt              # Cross-compilation script (Android NDK ARM64)
├── manifest.json               # LeviLaunchroid native mod descriptor
├── package_mod.sh              # Automated build, package, and ADB push script
├── config/
│   └── config.json             # Runtime preferences (camera, animations, speeds)
├── include/                    # Reverse-engineered C++ Bedrock headers
│   ├── mc/client/...           # UI, ScreenView, and Renderer definitions
│   └── glm/...                 # Vector math library
├── resources/                  # Raw assets (packaged with the mod)
│   ├── data/
│   │   ├── normal_cave.mesh    # Binary vertex buffer for the 3D cave model
│   │   └── normal_cave.schem   # Reference schematic data
│   └── textures/
│       └── animated_mojang/
│           ├── cave/           # Cave texture atlas & loading backdrop
│           └── title/          # 9 vertical strips of animated title frames
└── src/
    ├── animation/Timeline.h    # Presentation frame clock & cubic spline math
    ├── client/Client.cpp       # Native Dobby hooking pipeline & UI tree visitor
    ├── mod/MyMod.cpp           # Mod entry point & lifecycle hooks
    └── scene/                  # GLES 3.0 cave geometry & camera controllers
```

---

## Building from Source

### Prerequisites
- Linux or WSL2 (Ubuntu 22.04+ recommended)
- **Android NDK** r25c or higher (`export ANDROID_NDK_HOME=/path/to/ndk`)
- **CMake** 3.22+ and **Ninja**
- Target phone with **LeviLaunchroid** installed and ADB debugging enabled

### Build Command
Run the included packaging script:

```bash
chmod +x package_mod.sh
./package_mod.sh
```

The script will:
1. Compile `libAnimatedMojang.so` using the Android NDK for `arm64-v8a`.
2. Assemble the mod bundle into `dist/AnimatedMojang/`.
3. Package all mesh and texture resources.
4. Automatically deploy via ADB to `/sdcard/Android/data/org.levimc.launcher/files/mc_game/mods/AnimatedMojang/` (if an ADB device is connected).

---

## Configuration (`config.json`)

The mod creates and reads `config.json` in its mod directory:

```json
{
  "enabled": true,
  "minecraftTitleAnimation": true,
  "caveBackground": true,
  "replayOnReturnToMenu": false,
  "blockMenuInputDuringIntro": true,
  "maxPresentationSeconds": 15.0,
  "preferJsonMainMenu": true,
  "menuScreenNames": [
    "start_screen",
    "main_menu_screen"
  ],
  "titleControlNames": [
    "minecraft_title",
    "minecraft_title_image",
    "title_image"
  ]
}
```

---

## Credits & Acknowledgments

- **[MRUIAW/Animated-Mojang](https://github.com/MRUIAW/Animated-Mojang)**: Original Windows x64 C++ Bedrock mod port.
- **[chara2015/animated_mojang](https://github.com/chara2015/animated_mojang)**: Original Java Edition Fabric mod design, camera trajectories, and animation assets.
- **LiteLDev / LeviLamina Team**: For creating LeviLamina and LeviLaunchroid, enabling high-performance native C++ client modding on Android.
- **Universal Modder Project**: Autonomous reverse engineering, symbol recovery, and cross-platform porting pipeline.
